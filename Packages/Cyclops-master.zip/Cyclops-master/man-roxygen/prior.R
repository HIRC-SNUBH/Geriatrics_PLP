#' @section Prior:
#' Currently supported prior types are:
#' \tabular{ll}{
#' 	\verb{	"none"} \tab Useful for finding MLE \cr
#' 	\verb{	"laplace"} \tab L_1 regularization \cr
#'  \verb{  "normal"} \tab L_2 regularization \cr
#' }
#'
#' @param prior     A prior object. More details are given below.
